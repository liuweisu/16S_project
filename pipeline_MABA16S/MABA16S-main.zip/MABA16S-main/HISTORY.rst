=======
History
=======

0.1.0 (2022-06-16)
------------------

* First release on PyPI.
