



def renamer():
    """stub"""
    None 
