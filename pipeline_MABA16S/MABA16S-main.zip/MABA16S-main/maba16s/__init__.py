"""Top-level package for MABA16S."""

__author__ = """Casper Jamin"""
__email__ = 'casperjamin@gmail.com'
__version__ = '0.1.0'
