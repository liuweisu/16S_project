# NanoRTax: Documentation

The NanoRTax documentation is split into the following files:

1. [Introduction](../README.md)
2. [Running the pipeline](usage.md)
4. [Output and how to interpret the results](output.md)