# nf-core/nanoclust: Changelog

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## v1.0dev - [date]

Initial release of nf-core/nanoclust, created with the [nf-core](http://nf-co.re/) template.

### `Added`

### `Fixed`

### `Dependencies`

### `Deprecated`
